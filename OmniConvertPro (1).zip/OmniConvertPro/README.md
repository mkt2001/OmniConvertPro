# OmniConvert Pro

All-in-one OFFLINE file converter for Android (Kotlin + Jetpack Compose, Black + Blue animated UI).
Android 10+ (minSdk 29). Output is saved in `Downloads/OmniConvert`.

## APK kaise banaye (GitHub se)
1. GitHub par naya repository banao.
2. Is ZIP ke andar ki SAARI files/folders (`.github` folder samet) repository me upload karo.
3. Repository -> **Actions** tab -> **Build APK** -> **Run workflow** (ya push hote hi auto-build hota hai).
4. Build khatam hone par run kholo -> **Artifacts** -> `OmniConvertPro-debug-apk` download karo, ZIP khol kar `app-debug.apk` install karo.

## Android Studio se
Project folder kholo (Android Studio Koala+ / JDK 17) -> Run.

## Tools
Scan & OCR: Scan to PDF (document scanner), Image -> Text (OCR), Scanned PDF -> Text (OCR) - English + Hindi
Images: Image -> JPG / PNG / WEBP, Images -> PDF
PDF: PDF -> JPG / PNG, Merge, Split, Reorder, Rotate, Compress, Page Numbers, Lock, Unlock, Watermark, Sign (draw signature), PDF -> TXT
Documents: TXT -> PDF, HTML -> PDF, DOCX -> TXT / PDF, TXT -> DOCX, PDF -> DOCX (Editable / Original Look)
Data: XLSX -> CSV, CSV -> XLSX, JSON <-> CSV
Slides: PPTX -> PDF / TXT (text only)
Archives: Create ZIP, Extract ZIP

## Limits (offline ki wajah se)
- DOCX/PPTX -> PDF sirf text convert karta hai (fonts/images/layout nahi).
- PDF -> DOCX (Original Look) har page ko picture bana kar Word me rakhta hai (text edit nahi hota).
- Compress PDF pages ko images bana kar chhota karta hai (scanned PDFs ke liye best).
- Purane .doc / .xls / .ppt aur password wali PDF support nahi.
- HEIC sirf tab jab phone ka decoder support kare; TIFF support nahi.

## Naye features
- History: har conversion ki list (Home -> History), Open / Share / Remove.
- Share se kholo: kisi bhi app me file -> Share -> OmniConvert Pro -> suitable tool chuno.
- Scan to PDF Google Play services ka scanner use karta hai (Play services wale phone par).
- OCR ka model app ke andar hai (offline). ML Kit library apni telemetry ke liye INTERNET permission jod sakti hai; app aapki files kabhi upload nahi karta.
