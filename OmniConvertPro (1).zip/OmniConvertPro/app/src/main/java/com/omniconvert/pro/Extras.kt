package com.omniconvert.pro

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import androidx.compose.ui.geometry.Offset
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import kotlin.math.atan2
import kotlin.math.sqrt

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ----------------------------------------------------------------- History

data class HistoryItem(val uri: String, val name: String, val mime: String, val tool: String, val time: Long)

object History {
    private const val PREF = "omni_history"
    private const val KEY = "items"

    @Synchronized
    fun all(ctx: Context): List<HistoryItem> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            val out = ArrayList<HistoryItem>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    HistoryItem(
                        o.getString("uri"),
                        o.getString("name"),
                        o.getString("mime"),
                        o.optString("tool", ""),
                        o.optLong("time", 0L)
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun write(ctx: Context, list: List<HistoryItem>) {
        val a = JSONArray()
        for (h in list) {
            val o = JSONObject()
            o.put("uri", h.uri)
            o.put("name", h.name)
            o.put("mime", h.mime)
            o.put("tool", h.tool)
            o.put("time", h.time)
            a.put(o)
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    @Synchronized
    fun add(ctx: Context, tool: String, saved: List<Saved>) {
        if (saved.isEmpty()) return
        val now = System.currentTimeMillis()
        val fresh = saved.map { HistoryItem(it.uri.toString(), it.name, it.mime, tool, now) }
        write(ctx, (fresh.reversed() + all(ctx)).take(200))
    }

    @Synchronized
    fun remove(ctx: Context, uri: String) {
        write(ctx, all(ctx).filter { it.uri != uri })
    }

    @Synchronized
    fun clear(ctx: Context) {
        write(ctx, emptyList())
    }
}

// ---------------------------------------------------- Files shared to the app

object IntentUtil {
    @Suppress("DEPRECATION")
    fun uris(intent: Intent?): List<Uri> {
        if (intent == null) return emptyList()
        val action = intent.action
        if (action != Intent.ACTION_SEND && action != Intent.ACTION_SEND_MULTIPLE) return emptyList()
        val out = LinkedHashSet<Uri>()
        try {
            if (action == Intent.ACTION_SEND) {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                }
                if (u != null) out.add(u)
            } else {
                val l: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                }
                if (l != null) out.addAll(l)
            }
            val cd = intent.clipData
            if (out.isEmpty() && cd != null) {
                for (i in 0 until cd.itemCount) {
                    val u = cd.getItemAt(i).uri
                    if (u != null) out.add(u)
                }
            }
        } catch (_: Exception) {
        }
        return out.toList()
    }
}

// --------------------------------------------------------------------- OCR

object Ocr {
    const val HINDI = "Hindi + English"

    private fun <T> withRec(lang: String, block: (TextRecognizer) -> T): T {
        val rec: TextRecognizer = if (lang == HINDI) {
            TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        } else {
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        try {
            return block(rec)
        } finally {
            try {
                rec.close()
            } catch (_: Throwable) {
            }
        }
    }

    private fun read(rec: TextRecognizer, bmp: Bitmap): String {
        try {
            return Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0))).text
        } catch (e: Exception) {
            throw IllegalStateException("Text recognition failed: " + (e.cause?.message ?: e.message))
        }
    }

    fun images(ctx: Context, uris: List<Uri>, lang: String, progress: (Float) -> Unit): List<Saved> {
        val text = withRec(lang) { rec ->
            val sb = StringBuilder()
            uris.forEachIndexed { i, u ->
                val bmp = Img.decode(ctx, u, 3000)
                try {
                    val t = read(rec, bmp).trim()
                    if (uris.size > 1) sb.append("--- ").append(Util.displayName(ctx, u)).append(" ---\n")
                    sb.append(t).append("\n\n")
                } finally {
                    bmp.recycle()
                }
                progress((i + 1f) / uris.size)
            }
            sb.toString().trim()
        }
        if (text.isBlank()) throw IllegalStateException("No text found in the image(s).")
        val name = if (uris.size == 1) Util.baseName(ctx, uris[0]) + "_ocr.txt" else "ocr_" + Util.stamp() + ".txt"
        return listOf(Util.saveText(ctx, name, "text/plain", text))
    }

    fun pdf(ctx: Context, uri: Uri, lang: String, progress: (Float) -> Unit): List<Saved> {
        val text = PdfR.withRenderer(ctx, uri) { r ->
            val n = r.pageCount
            if (n > 100) throw IllegalStateException("OCR supports up to 100 pages at a time. Use Split / Extract Pages first.")
            withRec(lang) { rec ->
                val sb = StringBuilder()
                for (i in 0 until n) {
                    val rd = PdfR.render(r, i, 2.0f, 2600)
                    try {
                        val t = read(rec, rd.bmp).trim()
                        if (n > 1) sb.append("--- Page ").append(i + 1).append(" ---\n")
                        sb.append(t).append("\n\n")
                    } finally {
                        rd.bmp.recycle()
                    }
                    progress((i + 1f) / n)
                }
                sb.toString().trim()
            }
        }
        if (text.isBlank()) throw IllegalStateException("No text found in this PDF.")
        return listOf(Util.saveText(ctx, Util.baseName(ctx, uri) + "_ocr.txt", "text/plain", text))
    }
}

// ----------------------------------------- Watermark / signature bitmaps

object Sig {

    fun fromStrokes(strokes: List<List<Offset>>): Bitmap? {
        val pts = strokes.flatten()
        if (pts.size < 2) return null
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (p in pts) {
            if (p.x < minX) minX = p.x
            if (p.y < minY) minY = p.y
            if (p.x > maxX) maxX = p.x
            if (p.y > maxY) maxY = p.y
        }
        val pad = 8f
        val bw = maxOf(1f, maxX - minX) + 2 * pad
        val bh = maxOf(1f, maxY - minY) + 2 * pad
        val scale = minOf(700f / bw, 1400f / bh)
        val w = maxOf(1, (bw * scale).toInt())
        val h = maxOf(1, (bh * scale).toInt())
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.rgb(10, 25, 90)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = (5f * scale).coerceIn(4f, 14f)
        for (s in strokes) {
            for (k in 1 until s.size) {
                val a = s[k - 1]
                val b = s[k]
                c.drawLine(
                    (a.x - minX + pad) * scale, (a.y - minY + pad) * scale,
                    (b.x - minX + pad) * scale, (b.y - minY + pad) * scale,
                    paint
                )
            }
        }
        return out
    }

    fun watermarkBitmap(text: String, pw: Float, ph: Float): Bitmap {
        val w = 1000
        val h = ((w * ph / maxOf(1f, pw)).toInt()).coerceIn(200, 2000)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.argb(70, 110, 110, 110)
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 100f
        val diag = sqrt((w * w + h * h).toDouble()).toFloat()
        val measured = maxOf(1f, paint.measureText(text))
        paint.textSize = (100f * diag * 0.7f / measured).coerceIn(20f, 220f)
        val angle = -Math.toDegrees(atan2(h.toDouble(), w.toDouble())).toFloat()
        c.save()
        c.translate(w / 2f, h / 2f)
        c.rotate(angle)
        c.drawText(text, 0f, -(paint.ascent() + paint.descent()) / 2f, paint)
        c.restore()
        return out
    }
}

// ------------------------------------- PDF lock / unlock / watermark / sign

object PdfExtra {

    fun lock(ctx: Context, uri: Uri, password: String): List<Saved> {
        if (password.length < 4) throw IllegalArgumentException("Password must be at least 4 characters.")
        val doc = PdfBoxOps.load(ctx, uri)
        try {
            val policy = StandardProtectionPolicy(password, password, AccessPermission())
            policy.setEncryptionKeyLength(128)
            doc.protect(policy)
            val name = Util.baseName(ctx, uri) + "_locked.pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { doc.save(it) })
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }

    fun unlock(ctx: Context, uri: Uri, password: String): List<Saved> {
        PdfBoxOps.ensureInit(ctx)
        val doc: PDDocument = try {
            Util.open(ctx, uri).use { PDDocument.load(it, password) }
        } catch (e: InvalidPasswordException) {
            throw IllegalArgumentException("Wrong password.")
        } catch (e: IOException) {
            throw IllegalArgumentException("This file is not a valid PDF.")
        }
        try {
            if (!doc.isEncrypted) throw IllegalArgumentException("This PDF is not password-protected.")
            doc.setAllSecurityToBeRemoved(true)
            val name = Util.baseName(ctx, uri) + "_unlocked.pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { doc.save(it) })
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }

    fun watermark(ctx: Context, uri: Uri, text: String, progress: (Float) -> Unit): List<Saved> {
        val label = text.trim()
        if (label.isEmpty()) throw IllegalArgumentException("Enter the watermark text.")
        val doc = PdfBoxOps.load(ctx, uri)
        try {
            val cache = HashMap<String, PDImageXObject>()
            val n = doc.numberOfPages
            for (i in 0 until n) {
                val page = doc.getPage(i)
                val box = page.mediaBox
                val key = box.width.toInt().toString() + "x" + box.height.toInt()
                val img = cache.getOrPut(key) {
                    LosslessFactory.createFromImage(doc, Sig.watermarkBitmap(label, box.width, box.height))
                }
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.drawImage(img, box.lowerLeftX, box.lowerLeftY, box.width, box.height)
                }
                progress((i + 1f) / n)
            }
            val name = Util.baseName(ctx, uri) + "_watermarked.pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { doc.save(it) })
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }

    fun sign(ctx: Context, uri: Uri, sig: Bitmap?, position: String, pagesSpec: String): List<Saved> {
        if (sig == null) throw IllegalArgumentException("Draw your signature first.")
        val doc = PdfBoxOps.load(ctx, uri)
        try {
            val n = doc.numberOfPages
            val idx = if (pagesSpec.isBlank()) listOf(n - 1) else PdfBoxOps.parsePages(pagesSpec, n)
            val img = LosslessFactory.createFromImage(doc, sig)
            for (i in idx.distinct()) {
                val page = doc.getPage(i)
                val box = page.mediaBox
                val w = box.width * 0.28f
                val h = w * sig.height / sig.width
                val margin = 36f
                val x = when (position) {
                    "Bottom Left" -> box.lowerLeftX + margin
                    "Bottom Center" -> box.lowerLeftX + (box.width - w) / 2f
                    else -> box.lowerLeftX + box.width - w - margin
                }
                val y = box.lowerLeftY + margin
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.drawImage(img, x, y, w, h)
                }
            }
            val name = Util.baseName(ctx, uri) + "_signed.pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { doc.save(it) })
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }
}
