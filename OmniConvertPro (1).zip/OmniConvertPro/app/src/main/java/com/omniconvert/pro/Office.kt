package com.omniconvert.pro

import android.content.Context
import android.net.Uri
import android.util.Xml
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.OutputStream
import java.util.TreeMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object XmlUtil {
    fun esc(s: String): String {
        val sb = StringBuilder(s.length + 16)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch.code < 32 && ch != '\n' && ch != '\r' && ch != '\t' -> {}
                ch == '\uFFFE' || ch == '\uFFFF' -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun parser(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        return p
    }
}

// ------------------------------------------------------------ DOCX writing

object Docx {
    const val MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

    const val SECT_TEXT =
        "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>"
    const val SECT_IMAGES =
        "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"360\" w:right=\"360\" w:bottom=\"360\" w:left=\"360\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr>"

    fun textBody(paragraphs: List<String>): String {
        val sb = StringBuilder()
        for (p in paragraphs) {
            sb.append("<w:p>")
            val parts = p.split('\t')
            parts.forEachIndexed { i, part ->
                if (i > 0) sb.append("<w:r><w:tab/></w:r>")
                if (part.isNotEmpty()) {
                    sb.append("<w:r><w:t xml:space=\"preserve\">").append(XmlUtil.esc(part)).append("</w:t></w:r>")
                }
            }
            sb.append("</w:p>")
        }
        sb.append(SECT_TEXT)
        return sb.toString()
    }

    fun imagePara(i: Int, cx: Long, cy: Long): String {
        val id = i + 1
        val pb = if (i > 0) "<w:pageBreakBefore/>" else ""
        return "<w:p><w:pPr>" + pb + "<w:spacing w:before=\"0\" w:after=\"0\"/></w:pPr><w:r><w:drawing>" +
            "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
            "<wp:extent cx=\"" + cx + "\" cy=\"" + cy + "\"/>" +
            "<wp:docPr id=\"" + id + "\" name=\"Page " + id + "\"/>" +
            "<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"" + id + "\" name=\"image" + id + ".jpeg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"rId" + id + "\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"" + cx + "\" cy=\"" + cy + "\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
            "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
    }

    fun write(out: OutputStream, bodyXml: String, images: List<ByteArray>) {
        val z = ZipOutputStream(out)
        fun put(name: String, data: String) {
            z.putNextEntry(ZipEntry(name))
            z.write(data.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        put(
            "[Content_Types].xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
                "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "</Types>"
        )
        put(
            "_rels/.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "</Relationships>"
        )
        val rels = StringBuilder()
        rels.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        rels.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        for (i in images.indices) {
            rels.append("<Relationship Id=\"rId").append(i + 1)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image")
                .append(i + 1).append(".jpeg\"/>")
        }
        rels.append("</Relationships>")
        put("word/_rels/document.xml.rels", rels.toString())
        put(
            "word/document.xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
                "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<w:body>" + bodyXml + "</w:body></w:document>"
        )
        images.forEachIndexed { i, b ->
            z.putNextEntry(ZipEntry("word/media/image" + (i + 1) + ".jpeg"))
            z.write(b)
            z.closeEntry()
        }
        z.finish()
    }
}

// ------------------------------------------------------- Office reading

object Office {

    fun readZip(ctx: Context, uri: Uri, accept: (String) -> Boolean): Map<String, ByteArray> {
        val m = LinkedHashMap<String, ByteArray>()
        ZipInputStream(BufferedInputStream(Util.open(ctx, uri))).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory && accept(e.name)) m[e.name] = z.readBytes()
                e = z.nextEntry
            }
        }
        return m
    }

    fun docxParagraphs(ctx: Context, uri: Uri): List<String> {
        val files = readZip(ctx, uri) { it == "word/document.xml" }
        val bytes = files["word/document.xml"]
            ?: throw IllegalArgumentException("This is not a valid DOCX file (old .doc files are not supported).")
        val p = XmlUtil.parser(bytes)
        val paras = ArrayList<String>()
        val sb = StringBuilder()
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "w:t" -> inT = true
                    "w:tab" -> sb.append('\t')
                    "w:br", "w:cr" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "w:t" -> inT = false
                    "w:p" -> {
                        paras.add(sb.toString())
                        sb.setLength(0)
                    }
                    "w:tc" -> if (paras.isNotEmpty()) paras[paras.size - 1] = paras[paras.size - 1] + "\t"
                    "w:tr" -> if (paras.isNotEmpty()) paras[paras.size - 1] = paras[paras.size - 1].trimEnd('\t')
                }
            }
            ev = p.next()
        }
        if (sb.isNotEmpty()) paras.add(sb.toString())
        return paras
    }

    fun pptxSlides(ctx: Context, uri: Uri): List<String> {
        val re = Regex("ppt/slides/slide(\\d+)\\.xml")
        val files = readZip(ctx, uri) { re.matches(it) }
        if (files.isEmpty()) throw IllegalArgumentException("This is not a valid PPTX file (old .ppt files are not supported).")
        val names = files.keys.sortedBy { re.matchEntire(it)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
        val out = ArrayList<String>()
        names.forEachIndexed { idx, name ->
            val p = XmlUtil.parser(files.getValue(name))
            val sb = StringBuilder()
            sb.append("Slide ").append(idx + 1).append("\n\n")
            var inT = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "a:t" -> inT = true
                        "a:br" -> sb.append('\n')
                    }
                    XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "a:t" -> inT = false
                        "a:p" -> sb.append('\n')
                    }
                }
                ev = p.next()
            }
            out.add(sb.toString())
        }
        return out
    }

    private fun sheetNum(name: String): Int =
        name.filter { it.isDigit() }.toIntOrNull() ?: Int.MAX_VALUE

    fun xlsxRows(ctx: Context, uri: Uri): List<List<String>> {
        val files = readZip(ctx, uri) {
            it == "xl/sharedStrings.xml" || (it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml"))
        }
        val sheetName = files.keys.filter { it.startsWith("xl/worksheets/sheet") }.minByOrNull { sheetNum(it) }
            ?: throw IllegalArgumentException("This is not a valid XLSX file (old .xls files are not supported).")

        val shared = ArrayList<String>()
        val ss = files["xl/sharedStrings.xml"]
        if (ss != null) {
            val p = XmlUtil.parser(ss)
            val sb = StringBuilder()
            var inT = false
            var inPh = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "si" -> sb.setLength(0)
                        "rPh" -> inPh = true
                        "t" -> inT = true
                    }
                    XmlPullParser.TEXT -> if (inT && !inPh) sb.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "t" -> inT = false
                        "rPh" -> inPh = false
                        "si" -> shared.add(sb.toString())
                    }
                }
                ev = p.next()
            }
        }

        val grid = TreeMap<Int, TreeMap<Int, String>>()
        val p = XmlUtil.parser(files.getValue(sheetName))
        val buf = StringBuilder()
        var ref = ""
        var type = ""
        var inV = false
        var inT = false
        var seqRow = 0
        var seqCol = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> {
                        seqRow++
                        seqCol = 0
                    }
                    "c" -> {
                        ref = p.getAttributeValue(null, "r") ?: ""
                        type = p.getAttributeValue(null, "t") ?: ""
                        buf.setLength(0)
                        seqCol++
                    }
                    "v" -> inV = true
                    "t" -> inT = true
                }
                XmlPullParser.TEXT -> if (inV || inT) buf.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val raw = buf.toString()
                        val value = when (type) {
                            "s" -> shared.getOrElse(raw.trim().toIntOrNull() ?: -1) { "" }
                            "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                            else -> raw
                        }
                        var col = 0
                        var i = 0
                        while (i < ref.length && ref[i] in 'A'..'Z') {
                            col = col * 26 + (ref[i] - 'A' + 1)
                            i++
                        }
                        val rowNum = ref.substring(i).toIntOrNull()
                        val r = rowNum ?: seqRow
                        val c = if (col > 0) col else seqCol
                        seqCol = c
                        if (r in 1..1048576 && c in 1..16384 && value.isNotEmpty()) {
                            grid.getOrPut(r) { TreeMap() }[c] = value
                        }
                    }
                }
            }
            ev = p.next()
        }
        if (grid.isEmpty()) return emptyList()
        val maxRow = grid.lastKey()
        var maxCol = 1
        for (row in grid.values) if (row.lastKey() > maxCol) maxCol = row.lastKey()
        if (maxRow.toLong() * maxCol > 20_000_000L) {
            throw IllegalStateException("This spreadsheet is too large to convert on this phone.")
        }
        val out = ArrayList<List<String>>()
        for (r in 1..maxRow) {
            val row = grid[r]
            val cells = ArrayList<String>(maxCol)
            for (c in 1..maxCol) cells.add(row?.get(c) ?: "")
            out.add(cells)
        }
        return out
    }
}

// ----------------------------------------------------- CSV / JSON / XLSX out

object Data {
    private val NUM = Regex("-?(0|[1-9]\\d*)(\\.\\d+)?([eE][+-]?\\d+)?")

    fun parseCsv(text: String): List<List<String>> {
        val firstLine = text.lineSequence().firstOrNull() ?: ""
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } } ?: ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val f = StringBuilder()
        var q = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (q) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        f.append('"')
                        i++
                    } else {
                        q = false
                    }
                } else {
                    f.append(c)
                }
            } else if (c == '"') {
                q = true
            } else if (c == delim) {
                row.add(f.toString())
                f.setLength(0)
            } else if (c == '\n') {
                row.add(f.toString())
                f.setLength(0)
                rows.add(row)
                row = ArrayList()
            } else if (c != '\r') {
                f.append(c)
            }
            i++
        }
        if (f.isNotEmpty() || row.isNotEmpty()) {
            row.add(f.toString())
            rows.add(row)
        }
        while (rows.isNotEmpty() && rows[rows.size - 1].all { it.isEmpty() }) rows.removeAt(rows.size - 1)
        if (rows.isEmpty()) throw IllegalArgumentException("The CSV file is empty.")
        return rows
    }

    private fun csvEsc(v: String): String =
        if (v.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + v.replace("\"", "\"\"") + "\"" else v

    fun toCsv(rows: List<List<String>>): String {
        val sb = StringBuilder()
        for (row in rows) {
            row.forEachIndexed { i, v ->
                if (i > 0) sb.append(',')
                sb.append(csvEsc(v))
            }
            sb.append("\r\n")
        }
        return sb.toString()
    }

    fun jsonToRows(text: String): List<List<String>> {
        val t = text.trim()
        val arr: JSONArray = try {
            if (t.startsWith("[")) {
                JSONArray(t)
            } else {
                val o = JSONObject(t)
                var found: JSONArray? = null
                val keys = o.keys()
                while (keys.hasNext()) {
                    val v = o.opt(keys.next())
                    if (v is JSONArray) {
                        found = v
                        break
                    }
                }
                found ?: JSONArray().put(o)
            }
        } catch (e: org.json.JSONException) {
            throw IllegalArgumentException("This is not valid JSON.")
        }
        val cols = LinkedHashSet<String>()
        var hasPrimitive = false
        for (i in 0 until arr.length()) {
            val v = arr.opt(i)
            if (v is JSONObject) {
                val k = v.keys()
                while (k.hasNext()) cols.add(k.next())
            } else {
                hasPrimitive = true
            }
        }
        if (hasPrimitive) cols.add("value")
        val header = cols.toList()
        val rows = ArrayList<List<String>>()
        rows.add(header)
        for (i in 0 until arr.length()) {
            val v = arr.opt(i)
            val cells = ArrayList<String>()
            for (c in header) {
                val cell: Any? = if (v is JSONObject) v.opt(c) else if (c == "value") v else null
                cells.add(if (cell == null || cell == JSONObject.NULL) "" else cell.toString())
            }
            rows.add(cells)
        }
        return rows
    }

    fun rowsToJson(rows: List<List<String>>): String {
        val header = rows[0].mapIndexed { i, h -> if (h.isBlank()) "column" + (i + 1) else h }
        val arr = JSONArray()
        for (r in 1 until rows.size) {
            val o = JSONObject()
            for (j in header.indices) o.put(header[j], rows[r].getOrElse(j) { "" })
            arr.put(o)
        }
        return arr.toString(2)
    }

    private fun colName(index: Int): String {
        var n = index + 1
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.append('A' + r)
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }

    fun writeXlsx(out: OutputStream, rows: List<List<String>>) {
        if (rows.size > 1048576) throw IllegalArgumentException("Too many rows for an XLSX file.")
        if (rows.any { it.size > 16384 }) throw IllegalArgumentException("Too many columns for an XLSX file.")
        val z = ZipOutputStream(out)
        fun put(name: String, data: String) {
            z.putNextEntry(ZipEntry(name))
            z.write(data.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        put(
            "[Content_Types].xml",
            head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "</Types>"
        )
        put(
            "_rels/.rels",
            head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>"
        )
        put(
            "xl/workbook.xml",
            head + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        )
        put(
            "xl/_rels/workbook.xml.rels",
            head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "</Relationships>"
        )
        z.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
        val w = z.bufferedWriter(Charsets.UTF_8)
        w.write(head + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { r, row ->
            w.write("<row r=\"" + (r + 1) + "\">")
            row.forEachIndexed { c, v ->
                if (v.isNotEmpty()) {
                    val ref = colName(c) + (r + 1)
                    if (v.length <= 15 && NUM.matches(v)) {
                        w.write("<c r=\"" + ref + "\"><v>" + v + "</v></c>")
                    } else {
                        w.write("<c r=\"" + ref + "\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + XmlUtil.esc(v) + "</t></is></c>")
                    }
                }
            }
            w.write("</row>")
        }
        w.write("</sheetData></worksheet>")
        w.flush()
        z.closeEntry()
        z.finish()
    }
}

// --------------------------------------------------------------- Archives

object Zips {

    fun zipFiles(ctx: Context, uris: List<Uri>, progress: (Float) -> Unit): List<Saved> {
        val saved = Util.save(ctx, "archive_" + Util.stamp() + ".zip", "application/zip") { os ->
            val z = ZipOutputStream(os)
            val used = HashSet<String>()
            uris.forEachIndexed { i, u ->
                val orig = Util.displayName(ctx, u)
                var name = orig
                var k = 1
                while (!used.add(name)) {
                    val b = orig.substringBeforeLast('.', orig)
                    val e = orig.substringAfterLast('.', "")
                    name = if (e.isEmpty()) "$b ($k)" else "$b ($k).$e"
                    k++
                }
                z.putNextEntry(ZipEntry(name))
                Util.open(ctx, u).use { it.copyTo(z) }
                z.closeEntry()
                progress((i + 1).toFloat() / uris.size)
            }
            z.finish()
        }
        return listOf(saved)
    }

    fun unzip(ctx: Context, uri: Uri, progress: (Float) -> Unit): List<Saved> {
        val base = Util.baseName(ctx, uri)
        val out = ArrayList<Saved>()
        ZipInputStream(BufferedInputStream(Util.open(ctx, uri))).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) {
                    val nm = e.name.substringAfterLast('/').ifBlank { "file" }
                    val ext = nm.substringAfterLast('.', "").lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                    out.add(Util.save(ctx, nm, mime, base) { s -> z.copyTo(s) })
                    progress(0.5f)
                }
                e = z.nextEntry
            }
        }
        if (out.isEmpty()) throw IllegalArgumentException("No files found in this ZIP.")
        progress(1f)
        return out
    }
}
