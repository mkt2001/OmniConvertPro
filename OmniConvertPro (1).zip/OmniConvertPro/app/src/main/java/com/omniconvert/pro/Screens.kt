package com.omniconvert.pro

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- History

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(History.all(ctx)) }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("← Back", color = Cyan) }
            Spacer(Modifier.weight(1f))
            if (list.isNotEmpty()) {
                TextButton(onClick = {
                    History.clear(ctx)
                    list = emptyList()
                }) { Text("Clear all", color = ErrorC) }
            }
        }
        Text("🕘  History", color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Files are kept in Downloads/OmniConvert. Removing an item here does not delete the file.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Text("No conversions yet.", color = Muted, fontSize = 14.sp)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { h ->
                val saved = Saved(Uri.parse(h.uri), h.name, h.mime)
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardC),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(start = 14.dp, top = 10.dp, end = 6.dp, bottom = 2.dp)) {
                        Text(h.name, color = TextC, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(h.tool + "  •  " + fmt.format(Date(h.time)), color = Muted, fontSize = 11.sp)
                        Row {
                            TextButton(onClick = { openFile(ctx, saved) }) { Text("Open", color = Cyan) }
                            TextButton(onClick = { shareFile(ctx, saved) }) { Text("Share", color = Cyan) }
                            TextButton(onClick = {
                                History.remove(ctx, h.uri)
                                list = History.all(ctx)
                            }) { Text("Remove", color = ErrorC) }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------- Files shared into the app

@Composable
fun IncomingScreen(files: List<Uri>, onPick: (Tool) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val name = remember(files) { if (files.isEmpty()) "" else Util.displayName(ctx, files[0]) }
    val mime = remember(files) { if (files.isEmpty()) "" else (ctx.contentResolver.getType(files[0]) ?: "") }
    val list = remember(files) { Registry.matching(name, mime, files.size > 1) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Back", color = Cyan) }
        Text("📥  File received", color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        val label = if (files.size > 1) name + "  (+" + (files.size - 1) + " more)" else name
        Text(label, color = Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(16.dp))
        if (list.isEmpty()) {
            Text("No converter is available for this file type.", color = Muted, fontSize = 14.sp)
        } else {
            Text("Choose what to do:", color = Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            for (t in list) {
                ToolCard(t) { onPick(t) }
                Spacer(Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// --------------------------------------------------------- Signature pad

@Composable
fun SignaturePad(strokes: List<List<Offset>>, onChange: (List<List<Offset>>) -> Unit, modifier: Modifier = Modifier) {
    var current by remember { mutableStateOf(listOf<Offset>()) }
    Canvas(
        modifier = modifier.pointerInput(strokes) {
            detectDragGestures(
                onDragStart = { o -> current = listOf(o) },
                onDrag = { change, _ ->
                    change.consume()
                    current = current + change.position
                },
                onDragEnd = {
                    if (current.size > 1) onChange(strokes + listOf(current))
                    current = emptyList()
                },
                onDragCancel = { current = emptyList() }
            )
        }
    ) {
        val ink = Color(0xFF0A1960)
        val all = if (current.size > 1) strokes + listOf(current) else strokes
        for (pts in all) {
            if (pts.size > 1) {
                val path = Path()
                path.moveTo(pts[0].x, pts[0].y)
                for (k in 1 until pts.size) path.lineTo(pts[k].x, pts[k].y)
                drawPath(path, ink, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}
