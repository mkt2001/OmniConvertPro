package com.omniconvert.pro

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF05070D)
val SurfaceC = Color(0xFF0B101C)
val CardC = Color(0xFF111A2E)
val Blue = Color(0xFF2F80FF)
val Cyan = Color(0xFF00C2FF)
val Deep = Color(0xFF0A2A66)
val TextC = Color(0xFFE8EEFF)
val Muted = Color(0xFF8A96B3)
val ErrorC = Color(0xFFFF6B6B)

private val Scheme = darkColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    secondary = Cyan,
    onSecondary = Color.Black,
    background = Bg,
    onBackground = TextC,
    surface = SurfaceC,
    onSurface = TextC,
    surfaceVariant = CardC,
    onSurfaceVariant = Muted,
    outline = Color(0xFF2A3550)
)

@Composable
fun OmniTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
