package com.omniconvert.pro

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Saved(val uri: Uri, val name: String, val mime: String)

object Util {

    fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun clean(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "file" }

    fun displayName(ctx: Context, uri: Uri): String {
        var n: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) n = c.getString(i)
                }
            }
        } catch (_: Throwable) {
        }
        return n ?: uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    fun baseName(ctx: Context, uri: Uri): String {
        val d = displayName(ctx, uri)
        return clean(d.substringBeforeLast('.', d))
    }

    fun open(ctx: Context, uri: Uri): InputStream =
        ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open the selected file.")

    fun readText(ctx: Context, uri: Uri): String {
        val s = open(ctx, uri).use { it.readBytes().toString(Charsets.UTF_8) }
        return s.removePrefix("\uFEFF")
    }

    fun copyToCache(ctx: Context, uri: Uri, suffix: String): File {
        val f = File.createTempFile("omni_", suffix, ctx.cacheDir)
        open(ctx, uri).use { input ->
            f.outputStream().use { output -> input.copyTo(output) }
        }
        return f
    }

    fun save(
        ctx: Context,
        name: String,
        mime: String,
        sub: String? = null,
        write: (OutputStream) -> Unit
    ): Saved {
        val subPath = sub?.takeIf { it.isNotBlank() }?.let { "/" + clean(it) } ?: ""
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, clean(name))
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/OmniConvert" + subPath)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Cannot create the output file.")
        try {
            val os = resolver.openOutputStream(uri) ?: throw IllegalStateException("Cannot write the output file.")
            os.use { write(it) }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (t: Throwable) {
            try {
                resolver.delete(uri, null, null)
            } catch (_: Throwable) {
            }
            throw t
        }
        return Saved(uri, clean(name), mime)
    }

    fun saveText(ctx: Context, name: String, mime: String, text: String, bom: Boolean = false): Saved =
        save(ctx, name, mime) { os ->
            if (bom) os.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            os.write(text.toByteArray(Charsets.UTF_8))
        }
}
