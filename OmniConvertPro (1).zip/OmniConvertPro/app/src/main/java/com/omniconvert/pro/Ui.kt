package com.omniconvert.pro

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class Screen {
    object Home : Screen()
    object Hist : Screen()
    class Pick(val files: List<Uri>) : Screen()
    class Run(val tool: Tool, val files: List<Uri>) : Screen()
}

@Composable
fun App(incoming: List<Uri>, onIncomingHandled: () -> Unit) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    LaunchedEffect(incoming) {
        if (incoming.isNotEmpty()) {
            screen = Screen.Pick(incoming)
            onIncomingHandled()
        }
    }
    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        AnimatedContent(
            targetState = screen,
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "nav"
        ) { s ->
            when (s) {
                is Screen.Home -> HomeScreen(
                    onOpen = { screen = Screen.Run(it, emptyList()) },
                    onHistory = { screen = Screen.Hist }
                )
                is Screen.Hist -> HistoryScreen(onBack = { screen = Screen.Home })
                is Screen.Pick -> IncomingScreen(
                    files = s.files,
                    onPick = { screen = Screen.Run(it, s.files) },
                    onBack = { screen = Screen.Home }
                )
                is Screen.Run -> ToolScreen(tool = s.tool, initial = s.files, onBack = { screen = Screen.Home })
            }
        }
    }
}

// ------------------------------------------------------------------ Home

@Composable
fun HomeScreen(onOpen: (Tool) -> Unit, onHistory: () -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize().statusBarsPadding()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { Header(Registry.tools.size) }
        item(span = { GridItemSpan(maxLineSpan) }) {
            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) {
                Text("🕘  History", color = Cyan)
            }
        }
        for (cat in Cat.values()) {
            val list = Registry.tools.filter { it.cat == cat }
            if (list.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        text = cat.label,
                        color = Cyan,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(list, key = { it.id }) { t -> ToolCard(t) { onOpen(t) } }
            }
        }
    }
}

@Composable
fun Header(count: Int) {
    val inf = rememberInfiniteTransition(label = "hdr")
    val shift by inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse),
        label = "shift"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(Blue, Cyan.copy(alpha = 0.85f), Deep),
                    start = Offset(0f, 0f),
                    end = Offset(500f + 700f * shift, 400f)
                )
            )
            .padding(22.dp)
    ) {
        Column {
            Text("OmniConvert Pro", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("One app. Every file converter.", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                "🔒 100% offline  •  no uploads  •  $count tools",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ToolCard(tool: Tool, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, label = "press")
    Card(
        onClick = onClick,
        interactionSource = src,
        colors = CardDefaults.cardColors(containerColor = CardC),
        border = BorderStroke(1.dp, Blue.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .graphicsLayer {
                scaleX = sc
                scaleY = sc
            }
            .fillMaxWidth()
            .heightIn(min = 124.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(tool.emoji, fontSize = 26.sp)
            Spacer(Modifier.height(8.dp))
            Text(tool.title, color = TextC, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(tool.desc, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------ Helpers

private fun <T> List<T>.swapped(i: Int, j: Int): List<T> {
    if (i < 0 || j < 0 || i >= size || j >= size) return this
    val m = toMutableList()
    val t = m[i]
    m[i] = m[j]
    m[j] = t
    return m
}

fun friendly(t: Throwable): String = when {
    t is OutOfMemoryError -> "Not enough memory for this file. Try a smaller file or fewer files at once."
    t is SecurityException -> "This file is protected or restricted and can't be opened."
    else -> t.message ?: "Conversion failed (" + t.javaClass.simpleName + ")"
}

fun openFile(ctx: Context, s: Saved) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(s.uri, s.mime)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found to open this file.", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not open the file.", Toast.LENGTH_SHORT).show()
    }
}

fun shareFile(ctx: Context, s: Saved) {
    try {
        val i = Intent(Intent.ACTION_SEND)
        i.type = s.mime
        i.putExtra(Intent.EXTRA_STREAM, s.uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share the file.", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun Chips(values: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (v in values) {
            FilterChip(selected = v == selected, onClick = { onSelect(v) }, label = { Text(v) })
        }
    }
}

// ------------------------------------------------------------ Tool screen

@Composable
fun ToolScreen(tool: Tool, initial: List<Uri>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(if (tool.multi) initial else initial.take(1)) }
    var quality by remember { mutableStateOf(if (tool.id == "pdf_compress") 60f else 85f) }
    var pages by remember { mutableStateOf("") }
    var rotate by remember { mutableStateOf(90) }
    var pageSize by remember { mutableStateOf("A4") }
    var password by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var position by remember { mutableStateOf("Bottom Right") }
    var lang by remember { mutableStateOf("English") }
    var strokes by remember { mutableStateOf(listOf<List<Offset>>()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var error by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf(listOf<Saved>()) }

    val names = remember(files) { files.map { Util.displayName(ctx, it) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            files = if (tool.multi) (files + uris).distinct() else uris.take(1)
            results = emptyList()
            error = null
        }
    }

    val scanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val pdfUri = GmsDocumentScanningResult.fromActivityResultIntent(res.data)?.pdf?.uri
            if (pdfUri == null) {
                error = "No scan result was received."
            } else {
                scope.launch {
                    busy = true
                    error = null
                    results = emptyList()
                    try {
                        val saved = withContext(Dispatchers.IO) {
                            val s = Util.save(app, "scan_" + Util.stamp() + ".pdf", "application/pdf") { os ->
                                Util.open(app, pdfUri).use { it.copyTo(os) }
                            }
                            History.add(app, tool.title, listOf(s))
                            s
                        }
                        results = listOf(saved)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        error = friendly(t)
                    } finally {
                        busy = false
                    }
                }
            }
        }
    }

    fun startScan() {
        val act = ctx.findActivity()
        if (act == null) {
            error = "The scanner cannot start here."
            return
        }
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(25)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(opts).getStartScanIntent(act)
            .addOnSuccessListener { sender -> scanLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
            .addOnFailureListener { e ->
                error = "The scanner is not available on this phone (it needs Google Play services). " + (e.message ?: "")
            }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Back", color = Cyan) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tool.emoji, fontSize = 34.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(tool.title, color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(tool.desc, color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(16.dp))

        if (tool.hint.isNotEmpty() && Opt.PAGES !in tool.opts) {
            Text(tool.hint, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
        }

        if (tool.kind == "scan") {
            Button(onClick = { startScan() }, enabled = !busy, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                Text("📷  Start scanner", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Button(onClick = { picker.launch(tool.accept) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (tool.multi) "Choose file(s)" else "Choose file")
            }
        }

        if (files.isNotEmpty() && tool.kind != "scan") {
            Spacer(Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = CardC),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp)) {
                    files.forEachIndexed { i, _ ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = (i + 1).toString() + ". " + names.getOrElse(i) { "file" },
                                color = TextC,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (tool.multi && !busy) {
                                TextButton(onClick = { files = files.swapped(i, i - 1) }) { Text("↑") }
                                TextButton(onClick = { files = files.swapped(i, i + 1) }) { Text("↓") }
                                TextButton(onClick = { files = files.filterIndexed { k, _ -> k != i } }) { Text("✕", color = ErrorC) }
                            }
                        }
                    }
                }
            }
        }

        if (Opt.QUALITY in tool.opts) {
            Spacer(Modifier.height(16.dp))
            Text("Quality: " + quality.toInt() + "%", color = TextC, fontSize = 14.sp)
            Slider(value = quality, onValueChange = { quality = it }, valueRange = 30f..100f)
        }
        if (Opt.PAGES in tool.opts) {
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = pages,
                onValueChange = { pages = it },
                label = { Text(tool.hint) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (Opt.PASSWORD in tool.opts) {
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (Opt.TEXT in tool.opts) {
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Watermark text") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (Opt.ROTATE in tool.opts) {
            Spacer(Modifier.height(16.dp))
            Text("Rotate clockwise", color = TextC, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Chips(listOf("90", "180", "270"), rotate.toString()) { rotate = it.toInt() }
        }
        if (Opt.PAGESIZE in tool.opts) {
            Spacer(Modifier.height(16.dp))
            Text("Page size", color = TextC, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            val sizes = if (tool.id == "img_pdf") listOf("A4", "Letter", "Original") else listOf("A4", "Letter")
            Chips(sizes, pageSize) { pageSize = it }
        }
        if (Opt.POSITION in tool.opts) {
            Spacer(Modifier.height(16.dp))
            Text("Signature position", color = TextC, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Chips(listOf("Bottom Left", "Bottom Center", "Bottom Right"), position) { position = it }
        }
        if (Opt.LANG in tool.opts) {
            Spacer(Modifier.height(16.dp))
            Text("Text language", color = TextC, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Chips(listOf("English", Ocr.HINDI), lang) { lang = it }
        }
        if (tool.kind == "sign") {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Draw your signature", color = TextC, fontSize = 14.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { strokes = emptyList() }) { Text("Clear", color = ErrorC) }
            }
            Spacer(Modifier.height(6.dp))
            SignaturePad(
                strokes = strokes,
                onChange = { strokes = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
            )
        }

        if (tool.kind != "scan") {
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val picked = files
                    val sigBmp = if (tool.kind == "sign") Sig.fromStrokes(strokes) else null
                    val params = Params(quality.toInt(), pages, rotate, pageSize, password, text, position, lang, sigBmp)
                    scope.launch {
                        busy = true
                        progress = 0f
                        error = null
                        results = emptyList()
                        try {
                            val r = withContext(Dispatchers.IO) {
                                val out = tool.exec(app, picked, params) { v -> progress = v }
                                History.add(app, tool.title, out)
                                out
                            }
                            results = r
                        } catch (e: CancellationException) {
                            throw e
                        } catch (t: Throwable) {
                            error = friendly(t)
                        } finally {
                            busy = false
                        }
                    }
                },
                enabled = files.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
            ) {
                Text(if (busy) "Working..." else "Convert", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (busy) {
            Spacer(Modifier.height(12.dp))
            if (progress <= 0f) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Cyan)
            } else {
                LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth(), color = Cyan)
            }
        }

        val err = error
        if (err != null) {
            Spacer(Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1114)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(err, color = ErrorC, fontSize = 13.sp, modifier = Modifier.padding(14.dp))
            }
        }

        if (results.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text("✅ Done - saved in Downloads/OmniConvert", color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            for (s in results) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardC),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 12.dp, end = 4.dp)) {
                        Text(
                            s.name,
                            color = TextC,
                            fontSize = 13.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(vertical = 10.dp)
                        )
                        TextButton(onClick = { openFile(ctx, s) }) { Text("Open", color = Cyan) }
                        TextButton(onClick = { shareFile(ctx, s) }) { Text("Share", color = Cyan) }
                    }
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}
