package com.omniconvert.pro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.text.StaticLayout
import android.text.TextPaint
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayOutputStream
import java.io.IOException

// ---------------------------------------------------------------- Images

object Img {

    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
        try {
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val m = maxOf(w, h)
                if (m > maxSide) {
                    val s = maxSide.toFloat() / m
                    decoder.setTargetSize(maxOf(1, (w * s).toInt()), maxOf(1, (h * s).toInt()))
                }
            }
        } catch (e: IOException) {
            throw IllegalArgumentException(
                "Can't read \"" + Util.displayName(ctx, uri) + "\" - unsupported or damaged image."
            )
        }
    }

    fun flatten(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)
        return out
    }

    @Suppress("DEPRECATION")
    private fun webp(): Bitmap.CompressFormat =
        if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    fun convert(ctx: Context, uris: List<Uri>, target: String, quality: Int, progress: (Float) -> Unit): List<Saved> {
        val fmt: Bitmap.CompressFormat
        val mime: String
        val ext: String
        when (target) {
            "jpg" -> { fmt = Bitmap.CompressFormat.JPEG; mime = "image/jpeg"; ext = "jpg" }
            "png" -> { fmt = Bitmap.CompressFormat.PNG; mime = "image/png"; ext = "png" }
            else -> { fmt = webp(); mime = "image/webp"; ext = "webp" }
        }
        val q = if (target == "png") 100 else quality.coerceIn(1, 100)
        val out = ArrayList<Saved>()
        uris.forEachIndexed { i, u ->
            val base = Util.baseName(ctx, u)
            val bmp = decode(ctx, u, 4096)
            try {
                val flat = if (target == "jpg") flatten(bmp) else bmp
                try {
                    out.add(Util.save(ctx, "$base.$ext", mime) { s ->
                        if (!flat.compress(fmt, q, s)) throw IllegalStateException("Could not encode the image.")
                    })
                } finally {
                    if (flat !== bmp) flat.recycle()
                }
            } finally {
                bmp.recycle()
            }
            progress((i + 1).toFloat() / uris.size)
        }
        return out
    }

    fun imagesToPdf(ctx: Context, uris: List<Uri>, pageSize: String, progress: (Float) -> Unit): List<Saved> {
        val n = uris.size
        val maxSide = when {
            n <= 5 -> 2200
            n <= 15 -> 1600
            n <= 40 -> 1200
            else -> 900
        }
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val pdf = PdfDocument()
        try {
            uris.forEachIndexed { i, u ->
                val bmp = decode(ctx, u, maxSide)
                var pw: Int
                var ph: Int
                val margin: Float
                if (pageSize == "Original") {
                    pw = (bmp.width * 72f / 150f).toInt().coerceAtLeast(50)
                    ph = (bmp.height * 72f / 150f).toInt().coerceAtLeast(50)
                    margin = 0f
                } else {
                    if (pageSize == "Letter") { pw = 612; ph = 792 } else { pw = 595; ph = 842 }
                    if (bmp.width > bmp.height) { val t = pw; pw = ph; ph = t }
                    margin = 18f
                }
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
                val c = page.canvas
                c.drawColor(Color.WHITE)
                val s = minOf((pw - 2 * margin) / bmp.width, (ph - 2 * margin) / bmp.height)
                val dw = bmp.width * s
                val dh = bmp.height * s
                val l = (pw - dw) / 2f
                val t = (ph - dh) / 2f
                c.drawBitmap(bmp, null, RectF(l, t, l + dw, t + dh), paint)
                pdf.finishPage(page)
                progress((i + 1).toFloat() / n)
            }
            return listOf(Util.save(ctx, "images_" + Util.stamp() + ".pdf", "application/pdf") { pdf.writeTo(it) })
        } finally {
            pdf.close()
        }
    }
}

// ------------------------------------------------- PDF rendering (PdfRenderer)

class Rendered(val bmp: Bitmap, val w: Int, val h: Int)

object PdfR {

    fun <T> withRenderer(ctx: Context, uri: Uri, block: (PdfRenderer) -> T): T {
        val f = Util.copyToCache(ctx, uri, ".pdf")
        try {
            val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = try {
                    PdfRenderer(pfd)
                } catch (e: Exception) {
                    throw IllegalArgumentException("This file is not a valid PDF, or it is password-protected.")
                }
                try {
                    return block(r)
                } finally {
                    r.close()
                }
            } finally {
                pfd.close()
            }
        } finally {
            f.delete()
        }
    }

    fun render(r: PdfRenderer, index: Int, scale: Float, maxSide: Int): Rendered {
        val p = r.openPage(index)
        try {
            var s = scale
            val longest = maxOf(p.width, p.height)
            if (longest * s > maxSide) s = maxSide.toFloat() / longest
            val bw = maxOf(1, (p.width * s).toInt())
            val bh = maxOf(1, (p.height * s).toInt())
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return Rendered(bmp, p.width, p.height)
        } finally {
            p.close()
        }
    }

    fun toImages(ctx: Context, uri: Uri, png: Boolean, quality: Int, progress: (Float) -> Unit): List<Saved> {
        val base = Util.baseName(ctx, uri)
        val fmt = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        val mime = if (png) "image/png" else "image/jpeg"
        val ext = if (png) "png" else "jpg"
        val q = if (png) 100 else quality.coerceIn(1, 100)
        return withRenderer(ctx, uri) { r ->
            val n = r.pageCount
            val out = ArrayList<Saved>()
            for (i in 0 until n) {
                val rd = render(r, i, 2.5f, 3000)
                try {
                    out.add(Util.save(ctx, base + "_page_" + (i + 1) + "." + ext, mime) { s ->
                        if (!rd.bmp.compress(fmt, q, s)) throw IllegalStateException("Could not encode the page.")
                    })
                } finally {
                    rd.bmp.recycle()
                }
                progress((i + 1).toFloat() / n)
            }
            out
        }
    }

    fun compress(ctx: Context, uri: Uri, quality: Int, progress: (Float) -> Unit): List<Saved> {
        val base = Util.baseName(ctx, uri)
        val q = quality.coerceIn(20, 100)
        val scale = (q / 100f * 1.6f).coerceIn(0.5f, 1.6f)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        return withRenderer(ctx, uri) { r ->
            val n = r.pageCount
            val pdf = PdfDocument()
            try {
                var held = 0L
                for (i in 0 until n) {
                    val rd = render(r, i, scale, 2000)
                    val bos = ByteArrayOutputStream()
                    rd.bmp.compress(Bitmap.CompressFormat.JPEG, q, bos)
                    rd.bmp.recycle()
                    val bytes = bos.toByteArray()
                    val dec = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: throw IllegalStateException("Could not process page " + (i + 1))
                    held += dec.byteCount.toLong()
                    if (held > 380L * 1024 * 1024) {
                        throw IllegalStateException(
                            "This PDF is too large to compress on this phone. Lower the quality or split the PDF first."
                        )
                    }
                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(rd.w, rd.h, i + 1).create())
                    page.canvas.drawBitmap(dec, null, Rect(0, 0, rd.w, rd.h), paint)
                    pdf.finishPage(page)
                    progress((i + 1).toFloat() / n)
                }
                listOf(Util.save(ctx, base + "_compressed.pdf", "application/pdf") { pdf.writeTo(it) })
            } finally {
                pdf.close()
            }
        }
    }

    fun toDocxImages(ctx: Context, uri: Uri, progress: (Float) -> Unit): List<Saved> {
        val base = Util.baseName(ctx, uri)
        val jpgs = ArrayList<ByteArray>()
        val dims = ArrayList<IntArray>()
        withRenderer(ctx, uri) { r ->
            val n = r.pageCount
            if (n > 200) throw IllegalStateException("This PDF has too many pages for this mode (max 200).")
            for (i in 0 until n) {
                val rd = render(r, i, 1.8f, 2400)
                try {
                    val bos = ByteArrayOutputStream()
                    rd.bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
                    jpgs.add(bos.toByteArray())
                    dims.add(intArrayOf(rd.bmp.width, rd.bmp.height))
                } finally {
                    rd.bmp.recycle()
                }
                progress((i + 1).toFloat() / n)
            }
        }
        val availW = 11186L * 635L
        val availH = (16118L * 635L * 0.96).toLong()
        val sb = StringBuilder()
        for (i in jpgs.indices) {
            val w = dims[i][0].toDouble()
            val h = dims[i][1].toDouble()
            val s = minOf(availW / w, availH / h)
            sb.append(Docx.imagePara(i, (w * s).toLong(), (h * s).toLong()))
        }
        sb.append(Docx.SECT_IMAGES)
        return listOf(
            Util.save(ctx, "$base.docx", Docx.MIME) { Docx.write(it, sb.toString(), jpgs) }
        )
    }

    fun rotateMatrix(deg: Int): Matrix {
        val m = Matrix()
        m.postRotate(deg.toFloat())
        return m
    }
}

// ---------------------------------------------------- PDF editing (PDFBox)

object PdfBoxOps {

    fun ensureInit(ctx: Context) {
        PDFBoxResourceLoader.init(ctx.applicationContext)
    }

    fun load(ctx: Context, uri: Uri): PDDocument {
        ensureInit(ctx)
        try {
            return Util.open(ctx, uri).use { PDDocument.load(it) }
        } catch (e: IOException) {
            throw IllegalArgumentException(
                "\"" + Util.displayName(ctx, uri) + "\" is not a valid PDF, or it is password-protected."
            )
        }
    }

    fun parsePages(spec: String, count: Int): List<Int> {
        if (spec.isBlank()) return (0 until count).toList()
        val out = ArrayList<Int>()
        for (raw in spec.split(',', ';', ' ')) {
            val part = raw.trim()
            if (part.isEmpty()) continue
            if (part.contains('-')) {
                val a = part.substringBefore('-').trim()
                val b = part.substringAfter('-').trim()
                val s = if (a.isEmpty()) 1 else (a.toIntOrNull() ?: throw IllegalArgumentException("Invalid page range: $part"))
                val e = if (b.isEmpty()) count else (b.toIntOrNull() ?: throw IllegalArgumentException("Invalid page range: $part"))
                if (s < 1 || e > count || s > e) {
                    throw IllegalArgumentException("Page range $part is outside 1-$count")
                }
                for (p in s..e) out.add(p - 1)
            } else {
                val p = part.toIntOrNull() ?: throw IllegalArgumentException("Invalid page number: $part")
                if (p < 1 || p > count) throw IllegalArgumentException("Page $p is outside 1-$count")
                out.add(p - 1)
            }
        }
        if (out.isEmpty()) throw IllegalArgumentException("No pages selected.")
        return out
    }

    fun merge(ctx: Context, uris: List<Uri>, progress: (Float) -> Unit): List<Saved> {
        if (uris.size < 2) throw IllegalArgumentException("Select at least 2 PDF files to merge.")
        val docs = ArrayList<PDDocument>()
        val dest = PDDocument()
        try {
            uris.forEachIndexed { i, u ->
                val d = load(ctx, u)
                docs.add(d)
                for (p in d.pages) dest.importPage(p)
                progress((i + 1).toFloat() / uris.size)
            }
            return listOf(Util.save(ctx, "merged_" + Util.stamp() + ".pdf", "application/pdf") { dest.save(it) })
        } finally {
            try { dest.close() } catch (_: Throwable) {}
            for (d in docs) {
                try { d.close() } catch (_: Throwable) {}
            }
        }
    }

    fun selectPages(ctx: Context, uri: Uri, spec: String, suffix: String): List<Saved> {
        val src = load(ctx, uri)
        val dest = PDDocument()
        try {
            val idx = parsePages(spec, src.numberOfPages)
            for (i in idx) dest.importPage(src.getPage(i))
            val name = Util.baseName(ctx, uri) + "_" + suffix + ".pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { dest.save(it) })
        } finally {
            try { dest.close() } catch (_: Throwable) {}
            try { src.close() } catch (_: Throwable) {}
        }
    }

    fun rotate(ctx: Context, uri: Uri, deg: Int): List<Saved> {
        val doc = load(ctx, uri)
        try {
            for (p in doc.pages) {
                p.rotation = ((p.rotation + deg) % 360 + 360) % 360
            }
            val name = Util.baseName(ctx, uri) + "_rotated.pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { doc.save(it) })
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }

    fun pageNumbers(ctx: Context, uri: Uri, progress: (Float) -> Unit): List<Saved> {
        val doc = load(ctx, uri)
        try {
            val font = PDType1Font.HELVETICA
            val n = doc.numberOfPages
            for (i in 0 until n) {
                val page = doc.getPage(i)
                val box = page.mediaBox
                val label = (i + 1).toString() + " / " + n
                val tw = font.getStringWidth(label) / 1000f * 10f
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.beginText()
                    cs.setFont(font, 10f)
                    cs.newLineAtOffset(box.lowerLeftX + (box.width - tw) / 2f, box.lowerLeftY + 18f)
                    cs.showText(label)
                    cs.endText()
                }
                progress((i + 1).toFloat() / n)
            }
            val name = Util.baseName(ctx, uri) + "_numbered.pdf"
            return listOf(Util.save(ctx, name, "application/pdf") { doc.save(it) })
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }

    fun extractText(ctx: Context, uri: Uri): String {
        val doc = load(ctx, uri)
        try {
            val t = PDFTextStripper().getText(doc)
            if (t.isBlank()) {
                throw IllegalStateException(
                    "No selectable text found - this PDF may be scanned. Use \"PDF -> Images\" or \"PDF -> DOCX (Original Look)\"."
                )
            }
            return t
        } finally {
            try { doc.close() } catch (_: Throwable) {}
        }
    }
}

// ------------------------------------------------------- Text -> PDF layout

object TextPdf {

    fun render(ctx: Context, sections: List<CharSequence>, pageSize: String, name: String): List<Saved> {
        val pw: Int
        val ph: Int
        if (pageSize == "Letter") { pw = 612; ph = 792 } else { pw = 595; ph = 842 }
        val margin = 48
        val cw = pw - 2 * margin
        val chh = ph - 2 * margin
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = 12f
        paint.color = Color.BLACK
        val pdf = PdfDocument()
        var pageNo = 0
        try {
            for (sec in sections) {
                val text: CharSequence = if (sec.isBlank()) " " else sec
                val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, cw)
                    .setLineSpacing(0f, 1.15f)
                    .setIncludePad(false)
                    .build()
                var line = 0
                while (line < layout.lineCount) {
                    val startTop = layout.getLineTop(line)
                    var end = line
                    while (end < layout.lineCount && layout.getLineBottom(end) - startTop <= chh) end++
                    if (end == line) end = line + 1
                    val clipH = minOf(layout.getLineBottom(end - 1) - startTop, chh)
                    pageNo++
                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
                    val c = page.canvas
                    c.save()
                    c.translate(margin.toFloat(), margin.toFloat())
                    c.clipRect(0f, 0f, cw.toFloat(), clipH.toFloat())
                    c.translate(0f, -startTop.toFloat())
                    layout.draw(c)
                    c.restore()
                    pdf.finishPage(page)
                    line = end
                }
            }
            if (pageNo == 0) throw IllegalStateException("Nothing to convert.")
            return listOf(Util.save(ctx, name, "application/pdf") { pdf.writeTo(it) })
        } finally {
            pdf.close()
        }
    }
}
