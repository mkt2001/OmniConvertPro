package com.omniconvert.pro

import android.content.Context
import android.net.Uri
import android.text.Html

enum class Opt { QUALITY, PAGES, ROTATE, PAGESIZE }

enum class Cat(val label: String) {
    IMAGES("🖼️  Images"),
    PDF("📑  PDF Tools"),
    DOCS("📄  Documents"),
    SHEETS("📊  Spreadsheets & Data"),
    SLIDES("📽️  Presentations"),
    ARCHIVE("🗂️  Archives")
}

class Params(val quality: Int, val pages: String, val rotate: Int, val pageSize: String)

class Tool(
    val id: String,
    val title: String,
    val desc: String,
    val emoji: String,
    val cat: Cat,
    val accept: Array<String>,
    val multi: Boolean,
    val opts: Set<Opt> = emptySet(),
    val hint: String = "",
    val exec: (Context, List<Uri>, Params, (Float) -> Unit) -> List<Saved>
)

object Registry {
    private val IMG = arrayOf("image/*")
    private val PDF = arrayOf("application/pdf")
    private val ANY = arrayOf("*/*")

    private fun first(u: List<Uri>): Uri = u.firstOrNull() ?: throw IllegalArgumentException("Select a file first.")

    val tools: List<Tool> = listOf(
        // ------------------------------------------------------------ Images
        Tool("img_jpg", "Image → JPG", "PNG, WEBP, BMP, GIF, HEIC → JPG", "🖼️", Cat.IMAGES, IMG, true,
            opts = setOf(Opt.QUALITY)) { c, u, p, pr -> Img.convert(c, u, "jpg", p.quality, pr) },
        Tool("img_png", "Image → PNG", "JPG, WEBP, BMP, GIF, HEIC → PNG", "🖼️", Cat.IMAGES, IMG, true) { c, u, _, pr ->
            Img.convert(c, u, "png", 100, pr)
        },
        Tool("img_webp", "Image → WEBP", "JPG, PNG, BMP, GIF → WEBP", "🖼️", Cat.IMAGES, IMG, true,
            opts = setOf(Opt.QUALITY)) { c, u, p, pr -> Img.convert(c, u, "webp", p.quality, pr) },
        Tool("img_pdf", "Images → PDF", "Many images into one PDF", "🧾", Cat.IMAGES, IMG, true,
            opts = setOf(Opt.PAGESIZE),
            hint = "Use ↑ ↓ to set the page order.") { c, u, p, pr -> Img.imagesToPdf(c, u, p.pageSize, pr) },

        // --------------------------------------------------------------- PDF
        Tool("pdf_jpg", "PDF → JPG", "Every page as a JPG image", "📷", Cat.PDF, PDF, false,
            opts = setOf(Opt.QUALITY)) { c, u, p, pr -> PdfR.toImages(c, first(u), false, p.quality, pr) },
        Tool("pdf_png", "PDF → PNG", "Every page as a PNG image", "📷", Cat.PDF, PDF, false) { c, u, _, pr ->
            PdfR.toImages(c, first(u), true, 100, pr)
        },
        Tool("pdf_merge", "Merge PDF", "Combine many PDFs into one", "🔗", Cat.PDF, PDF, true,
            hint = "Select 2 or more PDFs. Use ↑ ↓ to set the order.") { c, u, _, pr -> PdfBoxOps.merge(c, u, pr) },
        Tool("pdf_split", "Split / Extract Pages", "Keep only the pages you need", "✂️", Cat.PDF, PDF, false,
            opts = setOf(Opt.PAGES),
            hint = "Pages to keep, e.g. 1-3,5,8-") { c, u, p, _ -> PdfBoxOps.selectPages(c, first(u), p.pages, "pages") },
        Tool("pdf_reorder", "Reorder Pages", "Change the order of pages", "🔀", Cat.PDF, PDF, false,
            opts = setOf(Opt.PAGES),
            hint = "New order, e.g. 3,1,2 (pages you leave out are removed)") { c, u, p, _ ->
            PdfBoxOps.selectPages(c, first(u), p.pages, "reordered")
        },
        Tool("pdf_rotate", "Rotate PDF", "Rotate every page", "🔄", Cat.PDF, PDF, false,
            opts = setOf(Opt.ROTATE)) { c, u, p, _ -> PdfBoxOps.rotate(c, first(u), p.rotate) },
        Tool("pdf_compress", "Compress PDF", "Make a PDF smaller", "🗜️", Cat.PDF, PDF, false,
            opts = setOf(Opt.QUALITY),
            hint = "Pages become images - best for scanned/photo PDFs. Text-only PDFs may not shrink.") { c, u, p, pr ->
            PdfR.compress(c, first(u), p.quality, pr)
        },
        Tool("pdf_numbers", "Add Page Numbers", "Number every page", "🔢", Cat.PDF, PDF, false) { c, u, _, pr ->
            PdfBoxOps.pageNumbers(c, first(u), pr)
        },
        Tool("pdf_txt", "PDF → TXT", "Extract text from a PDF", "🔤", Cat.PDF, PDF, false,
            hint = "Works for PDFs that have selectable text.") { c, u, _, _ ->
            val f = first(u)
            listOf(Util.saveText(c, Util.baseName(c, f) + ".txt", "text/plain", PdfBoxOps.extractText(c, f)))
        },

        // --------------------------------------------------------- Documents
        Tool("txt_pdf", "TXT → PDF", "Text file to PDF", "📝", Cat.DOCS, ANY, false,
            opts = setOf(Opt.PAGESIZE)) { c, u, p, _ ->
            val f = first(u)
            TextPdf.render(c, listOf(Util.readText(c, f)), p.pageSize, Util.baseName(c, f) + ".pdf")
        },
        Tool("html_pdf", "HTML → PDF", "Web page text to PDF", "🌐", Cat.DOCS, ANY, false,
            opts = setOf(Opt.PAGESIZE),
            hint = "Text, headings and basic styles are kept. Images and CSS layout are not.") { c, u, p, _ ->
            val f = first(u)
            val spanned = Html.fromHtml(Util.readText(c, f), Html.FROM_HTML_MODE_LEGACY)
            TextPdf.render(c, listOf(spanned), p.pageSize, Util.baseName(c, f) + ".pdf")
        },
        Tool("docx_txt", "DOCX → TXT", "Extract text from Word", "📃", Cat.DOCS, ANY, false) { c, u, _, _ ->
            val f = first(u)
            listOf(Util.saveText(c, Util.baseName(c, f) + ".txt", "text/plain", Office.docxParagraphs(c, f).joinToString("\n")))
        },
        Tool("docx_pdf", "DOCX → PDF", "Word text to PDF", "📄", Cat.DOCS, ANY, false,
            opts = setOf(Opt.PAGESIZE),
            hint = "Text and tables are converted as plain text. Fonts, images and exact layout are not kept.") { c, u, p, _ ->
            val f = first(u)
            val text = Office.docxParagraphs(c, f).joinToString("\n")
            TextPdf.render(c, listOf(text), p.pageSize, Util.baseName(c, f) + ".pdf")
        },
        Tool("txt_docx", "TXT → DOCX", "Text file to Word", "📝", Cat.DOCS, ANY, false) { c, u, _, _ ->
            val f = first(u)
            val body = Docx.textBody(Util.readText(c, f).split("\n").map { it.trimEnd('\r') })
            listOf(Util.save(c, Util.baseName(c, f) + ".docx", Docx.MIME) { Docx.write(it, body, emptyList()) })
        },
        Tool("pdf_docx_text", "PDF → DOCX (Editable)", "Text only, fully editable", "✏️", Cat.DOCS, PDF, false,
            hint = "Mode B: text is editable, but the page layout is not kept.") { c, u, _, _ ->
            val f = first(u)
            val body = Docx.textBody(PdfBoxOps.extractText(c, f).split("\n").map { it.trimEnd('\r') })
            listOf(Util.save(c, Util.baseName(c, f) + ".docx", Docx.MIME) { Docx.write(it, body, emptyList()) })
        },
        Tool("pdf_docx_img", "PDF → DOCX (Original Look)", "Each page placed as a picture", "🎯", Cat.DOCS, PDF, false,
            hint = "Mode A: the original look is kept exactly, but the text is not editable.") { c, u, _, pr ->
            PdfR.toDocxImages(c, first(u), pr)
        },

        // --------------------------------------------------- Spreadsheets / data
        Tool("xlsx_csv", "XLSX → CSV", "First sheet to CSV", "📊", Cat.SHEETS, ANY, false) { c, u, _, _ ->
            val f = first(u)
            listOf(Util.saveText(c, Util.baseName(c, f) + ".csv", "text/csv", Data.toCsv(Office.xlsxRows(c, f)), true))
        },
        Tool("csv_xlsx", "CSV → XLSX", "CSV to Excel", "📈", Cat.SHEETS, ANY, false) { c, u, _, _ ->
            val f = first(u)
            val rows = Data.parseCsv(Util.readText(c, f))
            listOf(
                Util.save(c, Util.baseName(c, f) + ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
                    Data.writeXlsx(it, rows)
                }
            )
        },
        Tool("json_csv", "JSON → CSV", "JSON list to CSV", "🧩", Cat.SHEETS, ANY, false) { c, u, _, _ ->
            val f = first(u)
            listOf(Util.saveText(c, Util.baseName(c, f) + ".csv", "text/csv", Data.toCsv(Data.jsonToRows(Util.readText(c, f))), true))
        },
        Tool("csv_json", "CSV → JSON", "CSV to JSON list", "🧩", Cat.SHEETS, ANY, false) { c, u, _, _ ->
            val f = first(u)
            listOf(Util.saveText(c, Util.baseName(c, f) + ".json", "application/json", Data.rowsToJson(Data.parseCsv(Util.readText(c, f)))))
        },

        // ------------------------------------------------------- Presentations
        Tool("pptx_pdf", "PPTX → PDF", "Slide text to PDF", "📽️", Cat.SLIDES, ANY, false,
            opts = setOf(Opt.PAGESIZE),
            hint = "Each slide's text goes on its own page. Pictures and design are not included.") { c, u, p, _ ->
            val f = first(u)
            TextPdf.render(c, Office.pptxSlides(c, f), p.pageSize, Util.baseName(c, f) + ".pdf")
        },
        Tool("pptx_txt", "PPTX → TXT", "Extract all slide text", "📃", Cat.SLIDES, ANY, false) { c, u, _, _ ->
            val f = first(u)
            listOf(Util.saveText(c, Util.baseName(c, f) + ".txt", "text/plain", Office.pptxSlides(c, f).joinToString("\n\n")))
        },

        // ------------------------------------------------------------ Archives
        Tool("zip_make", "Create ZIP", "Pack files into a ZIP", "📦", Cat.ARCHIVE, ANY, true) { c, u, _, pr ->
            Zips.zipFiles(c, u, pr)
        },
        Tool("zip_open", "Extract ZIP", "Unpack a ZIP file", "📂", Cat.ARCHIVE, ANY, false,
            hint = "Files are saved in Downloads/OmniConvert/<zip name>.") { c, u, _, pr ->
            Zips.unzip(c, first(u), pr)
        }
    )
}
